# Generated from 'CFBase.h'

def FOUR_CHAR_CODE(x): return x
kCFCompareLessThan = -1
kCFCompareEqualTo = 0
kCFCompareGreaterThan = 1
kCFNotFound = -1
kCFPropertyListImmutable = 0
kCFPropertyListMutableContainers = 1
kCFPropertyListMutableContainersAndLeaves = 2
# kCFStringEncodingInvalidId = (long)0xFFFFFFFF
kCFStringEncodingMacRoman = 0
kCFStringEncodingWindowsLatin1 = 0x0500
kCFStringEncodingISOLatin1 = 0x0201
kCFStringEncodingNextStepLatin = 0x0B01
kCFStringEncodingASCII = 0x0600
kCFStringEncodingUnicode = 0x0100
kCFStringEncodingUTF8 = 0x08000100
kCFStringEncodingNonLossyASCII = 0x0BFF
kCFCompareCaseInsensitive = 1
kCFCompareBackwards = 4
kCFCompareAnchored = 8
kCFCompareNonliteral = 16
kCFCompareLocalized = 32
kCFCompareNumerically = 64
kCFURLPOSIXPathStyle = 0
kCFURLHFSPathStyle = 1
kCFURLWindowsPathStyle = 2
